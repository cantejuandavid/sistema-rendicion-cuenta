user_pref("browser.shell.checkDefaultBrowser", false);
user_pref('extensions.autoDisableScopes', 14);
